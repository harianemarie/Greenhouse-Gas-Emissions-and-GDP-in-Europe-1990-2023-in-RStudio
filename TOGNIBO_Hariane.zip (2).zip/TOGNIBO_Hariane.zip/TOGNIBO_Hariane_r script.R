install.packages("tidyverse")
library(tidyverse)

# Import the data
# First, let's start by loading the necessary libraries
library(readr)
library(dplyr)

# View the working directory
getwd()

# Change my working directory
setwd("C:/Users/haria/OneDrive/Documents/r programming project")

# Data importation
# The variable named 'gdp' represents the national Gross Domestic Product (GDP)
# and 'ghg' represents Greenhouse Gas emissions

gdp <- read.csv(
  file = "data/raw/gdp__custom_18466451_linear_2_0.csv"
)

ghg <- read.csv(
  file = "data/raw/ghg__custom_18466612_linear_2_0.csv"
)

# Select the colums we will use later

gdp <-
  gdp |>
  select(geo, TIME_PERIOD, OBS_VALUE)

ghg <-
  ghg |>
  select(geo, TIME_PERIOD, OBS_VALUE)

# We will then rename the columns we selected

gdp <-
  gdp |>
  rename(
    country = geo, 
    year = TIME_PERIOD, 
    gdp = OBS_VALUE)

ghg <-
  ghg |>
  rename(
    country = geo, 
    year = TIME_PERIOD, 
    ghg = OBS_VALUE)

# Since the GHG variable is indexed to 1990 = 100, 
# we will rebase it to match the GDP index, that is, 2010 = 100

ghg <- ghg %>%
  group_by(country) %>%
  mutate(
    ghg_rebased = (ghg / ghg[year == 2010]) * 100
  ) %>%
  ungroup

ghg <-
  ghg |>
  select(country, year, ghg_rebased)

ghg <-
  ghg |>
  rename(ghg = ghg_rebased)

# Let's save the resulting tables

write.csv(gdp, file = "data/out/gdp.csv")

write.csv(ghg, file = "data/out/ghg.csv")

# Installing ggplot2 packages

install.packages("ggplot2")
library(ggplot2)

# Q8. Density plot of the GDP distribution

ggplot(gdp, aes(x = gdp))+
  geom_density(fill = "blue", alpha = 0.1, color = "black")+
  geom_vline(aes(xintercept = median(gdp, na.rm = TRUE)),   
             color = "black", linetype = "dashed", linewidth = 1)+
  labs(
    x = "GDP (chained volume, index 2010 = 100)",
    y = "Density",
    title = "Density of GDP"
  )+
  theme_minimal()

# Save the plot
ggsave("figs/Q8_density_plot_gdp.png")

# Q9. Density plot of GHG distribution

ggplot(ghg, aes(x = ghg))+
  geom_density(fill = "orange", alpha = 0.1, color = "black")+
  geom_vline(aes(xintercept = median(ghg, na.rm = TRUE)),   
             color = "black", linetype = "dashed", linewidth = 1)+
  labs(
    x = "GHG (in tons, index 2010 = 100)",
    y = "Density",
    title = "Density of GHG"
  )+
  theme_minimal()

# Save the plot
ggsave("figs/Q9_density_plot_ghg.png")

# Q10. Create a summary statistics table

stats_gdp <- gdp %>%
  summarise(
    Mean = mean(gdp, na.rm = TRUE),
    Sd = sd(gdp, na.rm = TRUE),
    Min = min(gdp, na.rm = TRUE),
    Max = max(gdp, na.rm = TRUE)
  )

stats_gdp

stats_ghg <- ghg %>%
  summarise(
    Mean = mean(ghg, na.rm = TRUE),
    Sd = sd(ghg, na.rm = TRUE),
    Min = min(ghg, na.rm = TRUE),
    Max = max(ghg, na.rm = TRUE)
  )

stats_ghg

stats_summary <- bind_rows(
  stats_gdp %>% mutate(Variable = "GDP"),
  stats_ghg %>% mutate(Variable = "GHG")
) %>%
  select(Variable, Mean, Sd, Min, Max)

stats_summary

# Save the table
write.csv(stats_summary, "tables/Q10_summary_statistics.csv", row.names = FALSE)

# Q11. Create a summary table by country

stats_gdp <- gdp %>%
  group_by(country) %>%
  summarise(
    Mean_gdp = mean(gdp, na.rm = TRUE),
    Sd_gdp = sd(gdp, na.rm = TRUE)
  )

stats_ghg <- ghg %>%
  group_by(country) %>%
  summarise(
    Mean_ghg = mean(ghg, na.rm = TRUE),
    Sd_ghg = sd(ghg, na.rm = TRUE)
  )

stats_country <- merge(stats_gdp, stats_ghg, by = "country")

stats_country

# Save the table

write.csv(stats_country, "tables/Q11_country_statisticals.csv", 
          row.names = FALSE)

# Q12. Let's plot the average evolution of GDP and GHG over time

# Calculate the average GDP per year

gdp_summary <- gdp %>%
  group_by(year) %>%
  summarise(
    Mean_gdp = mean(gdp, na.rm = TRUE)
    )

ggplot(gdp_summary, aes(x = year, y = Mean_gdp))+
geom_line(color = "black")+
geom_point(color = "blue")+
  labs(
    title = "Average GDP trend (1990–2023)",
    x = "Year",
    y = "Mean GDP"
  )+
  theme_minimal()

# Save the plot 
ggsave("figs/Q12_average_gdp_overtime.png")

# Calculate the average GHG per year

ghg_summary <- ghg %>%
  group_by(year) %>%
  summarise(
    Mean_ghg = mean(ghg, na.rm = TRUE)
  )

ggplot(ghg_summary, aes(x = year, y = Mean_ghg))+
  geom_line(color = "black")+
  geom_point(color = "purple")+
  labs(
    title = "Average trend of GHG emissions (1990–2023)",
    x = "Year",
    y = "Mean emissions"
  )+
  theme_minimal()

# Save the plot 
ggsave("figs/Q12_average_ghg_overtime.png")

# Q13. Let us plot the evolution of GDP and GHG
# for France and Norway in two separate graphs

# GDP evolution for two country

gdp_2countries <- gdp %>%
  filter(country %in% c("FR", "NO"))

ggplot(gdp_2countries, aes(x = year, y = gdp, color = country))+
  geom_line()+
  geom_point()+
  scale_color_manual(
    values = c("FR" = "#0000FF", "NO" = "#FF0000")
  )+
  labs(
    title = "GDP evolution (France vs Norway, 1990–2023)",
    x = "Year",
    y = "GDP (index 2010=100)",
    color = "country"
  )+
  theme_minimal()
    
# Save the plot 
ggsave("figs/Q13_GDP_France_Norway.png")

# GHG evolution for two country

ghg_2countries <- ghg %>%
  filter(country %in% c("FR", "NO"))

ggplot(ghg_2countries, aes(x = year, y = ghg, color = country))+
  geom_line()+
  geom_point()+
  scale_color_manual(
    values = c("FR" = "#0000FF", "NO" = "#FF0000")
  )+
  labs(
    title = "GHG evolution (France vs Norway, 1990–2023)",
    x = "Year",
    y = "GHG (index 2010=100)",
    color = "country"
  )+
  theme_minimal()

# Save the plot 
ggsave("figs/Q13_GHG_France_Norway.png")

# Q14. Let's calculate the change in GDP between 1990 and 2023 for each country,
# then rank the countries in a bar chart in descending order 

install.packages("gridExtra")
library(gridExtra)

gdp <- gdp %>% 
  arrange(country, year)

variation_gdp <- gdp %>%
  group_by(country) %>%
  summarise(
    var_gdp = last(gdp) - first(gdp)
  ) %>%
  arrange(desc(var_gdp)) 

bar_gdp <- ggplot(variation_gdp, aes(x = reorder(country, -var_gdp), 
                          y = var_gdp, fill = var_gdp))+
  geom_bar(stat = "identity",  fill = "#FF1493", color = "black")+
  coord_flip()+
  labs(
    title = "GDP variation (1990–2023)",
    x = "Country",
    y = "GDP Δ (Indice 2010=100)"
  )+
  theme_minimal()+
  theme(legend.position = "none")

bar_gdp

# Let's do the same thing for GHG

ghg <- ghg %>% 
  arrange(country, year)

variation_ghg <- ghg %>%
  group_by(country) %>%
  summarise(
var_ghg = last(ghg) - first(ghg)
  ) %>%
  arrange(desc(var_ghg)) 

bar_ghg <- ggplot(variation_ghg, aes(x = reorder(country, -var_ghg), 
                      y = var_ghg, fill = var_ghg))+
  geom_bar(stat = "identity", fill = "#FFA500", color = "black")+
  coord_flip()+
  labs(
    title = "GHG variation (1990–2023)",
    x = "Country",
    y = "GHG Δ (Indice 2010=100)"
  )+
  theme_minimal()+
  theme(legend.position = "none")

bar_ghg

# Now, let's display both plots on the same figure

grid.arrange (bar_ghg, bar_gdp, ncol = 2)
combined_bars <- grid.arrange (bar_ghg, bar_gdp, ncol = 2)
ggsave("figs/Q14_variations_per_country_gdp_ghg.png", combined_bars)

# Relationship between GDP and GHG

gdp_ghg <- merge(gdp, ghg, by = c("country", "year"))

# Save new database
write.csv(gdp_ghg, "data/out/gdp_ghg.csv")

summary(gdp_ghg)
str(gdp_ghg)

# Let's verify the number of observations we have
nrow(gdp_ghg) # Q7. Number of observation
table(gdp_ghg$country)
range(gdp_ghg$year)

# Q15. Let's plot a scatter plot of GDP and GHG with a linear fit

ggplot(gdp_ghg, aes(x = ghg, y = gdp))+
  geom_point(color = "black", alpha = 0.4)+
  geom_smooth(method = "lm", se = FALSE, color = "#E34234")+
  labs(
    title = "Relationship between GDP and GHG emissions (1990–2023)",
    x = "GHG emissions (index 2010 = 100)",
    y = "GDP (index 2010 = 100)"
  ) +
  theme_minimal()

ggsave("figs/Q15_scatter_linear_plot.png")

# Q16. Let's plot a scatter plot of GDP and GHG 
# with a quadratic regression line 

ggplot(gdp_ghg, aes(x = ghg, y = gdp))+
  geom_point(color = "darkblue", alpha = 0.6)+ 
  geom_smooth(method = "lm", formula = y ~ poly(x, 2, raw = TRUE), 
              se = TRUE, color = "#FF4500")+
  labs(
    title = "Relationship between GDP and GHG emissions (quadratic regression)",
    x = "GHG emissions (indice 2010 = 100)",
    y = "GDP (index 2010 = 100)"
  ) +
  theme_minimal()

ggsave("figs/Q16_scatter_quadratic_plot.png")

# Q17. Compute the temporal variations within each country for GDP and GHG. 
# Plot these variations against each other in a scatter plot with a linear fit

Δgdp_ghg <- gdp_ghg %>%
  group_by(country) %>%
  arrange(year, .by_group = TRUE) %>%
  mutate(
    Δghg = ghg - lag(ghg),
    Δgdp = gdp - lag(gdp)
  ) %>%
  ungroup()

ggplot(Δgdp_ghg, aes(x = Δghg, y = Δgdp))+
  geom_point(alpha = 0.8, color = "skyblue")+
  geom_smooth(method = "lm", se = FALSE, color = "red")+
  labs(
    title = "Relationship between annual changes in GDP and GHG emissions",
    x = "Annual change in GDP (ΔGDP)",
    y = "Annual change in GHG (ΔGHG)"
  ) +
  theme_minimal()

ggsave("figs/Q17_annual_changes_GDP_GHG.png")

# Q18. We estimate an OLS regression of GDP on GHG emissions and 
# present the estimation results in a summary table
# X = GHG and Y = GDP

install.packages("stargazer")
library(stargazer)

model_1 <- lm(gdp ~ ghg, data = gdp_ghg)
summary(model_1)

stargazer(model_1, type = "latex",
          title = "OLS Regression of GDP on GHG Emissions",
          dep.var.labels = "GDP (index 2010 = 100)",
          covariate.labels = "GHG emissions (index 2010 = 100)",
          align = TRUE, digits = 3,
          out = "tables/Q18_ols_regression.tex")

# Q19. We Estimate an OLS regression of Y on X, controlling 
# for country fixed effects and present the results of questions Q18 and Q19 
# in the same table.

model_2 <- lm(gdp ~ ghg + factor(country), data = gdp_ghg)
summary(model_2)

stargazer(model_1, model_2, 
      type = "latex",
      title  = "OLS Regression of GDP on GHG (Country Fixed Effects)",
      column.labels = c("Pooled OLS", "Country FE"),
      omit = "factor\\(country\\)",
      dep.var.labels = "GDP (index 2010 = 100)",
      covariate.labels = "GHG emissions (index 2010 = 100)",
      align = TRUE, digits = 3, add.lines = list(
      c("Country fixed effect", "No", "Yes")
  ),
      out = "tables/Q19_ols_regression_country_fixed.tex")

# Q20. Estimate an OLS regression of Y on X, controlling for both year 
# and country fixed effects and present the results of questions Q18, Q19, 
# and Q20 in a single table

model_3 <- lm(gdp ~ ghg + factor(country) + factor(year), data = gdp_ghg)
summary(model_3)

# Presentation in table

stargazer(model_1, model_2, model_3,
        type = "latex",
        title = "OLS Regressions of GDP on GHG Emissions (year and country fixed)",
        column.labels = c("Pooled OLS", "Country FE", "Country +Year FE"),
        omit = c("factor\\(country\\)", "factor\\(year\\)"),
        dep.var.labels = "GDP (index 2010 = 100)",
        covariate.labels = "GHG emissions (index 2010 = 100)",
        align = TRUE, digits = 3, add.lines = list(
            c("Country fixed effect", "No", "Yes", "Yes"),
            c("Year fixed effect", "No","No", "Yes")
          ),
        out = "tables/Q20_ols_regression_year_country_fixed.tex")
